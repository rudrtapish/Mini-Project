# Korean-Tourism
Recreating the Korean Tourism Website.

You can add features to the page1.html file to create a web page similar to the official website of korea tourism.

Happy Hacking:)
=======
>>>>>>> 3f455bdf956d1f0fd27ff10b1ea755a36c0c3637
